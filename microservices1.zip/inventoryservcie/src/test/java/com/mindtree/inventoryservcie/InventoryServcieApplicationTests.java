package com.mindtree.inventoryservcie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventoryServcieApplicationTests {

	@Test
	void contextLoads() {
	}

}
