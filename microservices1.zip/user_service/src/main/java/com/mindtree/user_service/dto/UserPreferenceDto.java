package com.mindtree.user_service.dto;

public class UserPreferenceDto {

}
