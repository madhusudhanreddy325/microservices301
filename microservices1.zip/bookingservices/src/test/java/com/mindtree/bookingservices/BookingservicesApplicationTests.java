package com.mindtree.bookingservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
